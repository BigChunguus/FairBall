using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControladorSonidos : MonoBehaviour
{

    //Esta clase servira para los sonidos de colisiones que tendran dentro del juego. Así, centralizandolo
    
    // Creamos una variable de "AudioClip" tipo array
    
    [SerializeField] private AudioClip[] audios;

    // Hacemos referencia al componente reproductor de audios
    private AudioSource controlAudio;
    // Start is called before the first frame update
    
    void Awake()
    {
        // Buscamos y referenciamos el componente "AudioSource"
        controlAudio = GetComponent<AudioSource>();
    }

    //Este metodo recibe un int y float, los cuales seran, el valor del array, y el volumen
    public void SeleccionAudio(int indice, float volumen){
        // Reproducimos el sonido
        controlAudio.PlayOneShot(audios[indice],volumen);
    }
}
