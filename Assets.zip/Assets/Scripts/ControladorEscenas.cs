using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
 
public class ControladorEscenas : MonoBehaviour
{
    //Estos 4 metodos, serán el control entre escenas principal
    // Metodo que carga el juego
    public void CargarJuego()
    {
        SceneManager.LoadScene(1);
    }
    // Metodo que carga el menu incial
    public void VolverMenu(){
        SceneManager.LoadScene(0);
    }
    // Metodo que cierra la aplicación
    public void Salir()
    {
        Application.Quit();
    }
    // Metodo que carga la escena de los controles
    public void Controles(){
        SceneManager.LoadScene(3);
    }
}