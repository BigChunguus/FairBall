using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Clase estatica en la cual guardaremos el ganador de la partida
public static class GanadorInfo
{
    // Variable estatica en la cual guardaremos el ganador  
    public static int Ganador { get; set; }
}