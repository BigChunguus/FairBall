using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovimientoPelota : MonoBehaviour
{
    public float velocidadInicial = 5f; // Velocidad inicial ed la pelota
    public float velocidadMaxima = 16f; // Velocidad maxima que tendrá la pelota
    public float velocidadMinima = 4f; // La velocidad minima que tendrá la pelota
    public float factorFrenado = 1.10f; // Variable la cual frenará la pelota poco a poco

    // Referencia a Rigidbody
    private Rigidbody2D rb;
    // Referencia a porteria
    private Porteria porteria; 
    // Referencia al controlador de sonidos
    private ControladorSonidos controladorSonidos; 
    void Start()
    {
        // Buscamos y referenciamos sus componentes
        porteria = FindObjectOfType<Porteria>();
        rb = GetComponent<Rigidbody2D>();
        controladorSonidos = FindObjectOfType<ControladorSonidos>();
        // LLamamos al metodo "IniciarPelota" en 2 segundos, para que el jugador se acostumbre
        Invoke("IniciarPelota",2f);
    }

    
    // Metodo inicial el cual lanzara la pelota
    void IniciarPelota()
    {
        //Variable aleatoria en el eje Y
        float direccionY = Random.Range(-1.0000f, 1.0000f);
        // Movemos la pelota siempre hacia la izquierda, y con la direccion en el eje Y dada
        Vector2 direccionInicial = new Vector2(-4f, direccionY).normalized;
        // Iniciamos el movimiento
        rb.velocity = direccionInicial * velocidadInicial;
    }

    // Metodo que reseteará la pelota, ependiedo de quien haya marcado
    void ReiniciarConRetraso(float posicionReinicio){
        //Llamamos al metodo dentro de 2 segundos
        Invoke("ResetearPelota", 2f);
        // Almacenar los parámetros en variables miembro para usarlos en ReiniciarPosicion
        posicionReinicioNuevo = posicionReinicio;
    }
    // Guardamos en que posicion debe reaprecer
    float posicionReinicioNuevo;
    //Metodo que resetea la pelota
    void ResetearPelota(){

        // Configura la nueva posición
        Vector3 nuevaPosicion = new Vector3(posicionReinicioNuevo,-0.45f,0f);

        // Reinicia la posición de la pelota
        transform.position = nuevaPosicion;

        // Genera una dirección aleatoria en el eje Y (-1 o 1)
        float direccionY = Random.Range(0, 2) == 0 ? -1f : 1f;

        // Variable de la nueva direccion
        Vector2 direccionReseteo;

        // Si marca el jugador, se lanzará hacia el enemigo, sino, a jugador
        if(posicionReinicioNuevo == 1f){
            direccionReseteo = new Vector2(5f, direccionY).normalized;
        }else{
            direccionReseteo = new Vector2(-5f, direccionY).normalized;
        }

        // Aplica la nueva dirección a la velocidad de la pelota
        rb.velocity = direccionReseteo * velocidadInicial;
    
    }
    // Cada frame reducimos la velocidad con la variable "factorfrenado"
    void FixedUpdate()
    {
        rb.velocity = rb.velocity.normalized * Mathf.Min(rb.velocity.magnitude / factorFrenado, velocidadMaxima);
    }

    // Metodo que manejara las colisiones
    void OnCollisionEnter2D(Collision2D col)
    {
        //Guardamos en un String
        string etiqueta = col.gameObject.tag;

        //Hacemos un switch para cada etiqueta.
        // Dependiendo de la etiqueta, emitira un sonido, y aumentará la velocidad
        switch (etiqueta)
        {
            case "Bumper":
                rb.velocity = rb.velocity.normalized * Mathf.Min(rb.velocity.magnitude * 2.5f, velocidadMaxima);
                controladorSonidos.SeleccionAudio(0,1.5f);
                break;
            case "Pared":
                rb.velocity = rb.velocity.normalized * Mathf.Min(rb.velocity.magnitude * 2f, velocidadMaxima);
                controladorSonidos.SeleccionAudio(2,2.5f);
                break;
            case "Jugador":
                rb.velocity = rb.velocity.normalized * Mathf.Min(rb.velocity.magnitude * 3f, velocidadMaxima);
                controladorSonidos.SeleccionAudio(3,2.5f);
                break;
            case "Triangulo":
                 rb.velocity = rb.velocity.normalized * Mathf.Min(rb.velocity.magnitude * 2f, velocidadMaxima);
                controladorSonidos.SeleccionAudio(1,1.5f);
                break;
            default:
                
                break;
        }
    }
    // Metodo que manejara los trigger
    void OnTriggerEnter2D(Collider2D trig){
        //Volvemos a guardarlo en un string
        string etiqueta = trig.gameObject.tag;
            switch (etiqueta){
                // Porteria del jugador
                case "Porteria1":
                        // Llama al método de la portería para anotar un punto
                        if (porteria != null)
                        {
                            porteria.AnotarPunto2();
                        }
                        // Resetea la posición de la pelota
                        ReiniciarConRetraso(-1f);
                        break;
                // Porteria del enemigo
                case "Porteria2":
                    // Llama al método de la portería para anotar un punto
                    if (porteria != null)
                    {
                        porteria.AnotarPunto1();
                    }
                    // Resetea la posición de la pelota
                    ReiniciarConRetraso(1f);
                    
                    break;
        }
    }
}
