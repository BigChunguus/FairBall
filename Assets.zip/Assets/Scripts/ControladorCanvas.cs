using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ControladorCanvas : MonoBehaviour
{

    // Declaro 2 variables de tipo "Text", 
    // en la cual guardare el texto dela puntuacion
    public Text textoJugador1;
    public Text textoJugador2;

    // Este metodo recibira el puntaje actual, y actualizara el marcador del juego
    public void ActualizarTextoPuntos(int puntosJugador1, int puntosJugador2)
    {
        // Actualizamos el texto de las 2 variables.
        textoJugador1.text = ""+ puntosJugador1;    
        textoJugador2.text = "" + puntosJugador2;
    }
}