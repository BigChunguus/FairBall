using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class EscenaFinal : MonoBehaviour
{
    // Variable de tipo texto, el cual guardara el mensaje final
    public Text resultadoFinal;

    // LLamamos al metodo "MostrarGanador"
    void Start()
    {
        MostrarGanador();
    }

    // Metodo el cual recojera el ganador que tenemos guardado en la variable estatica, 
    // de la clase estatica GanadorInfo. (Fue la unica manera que funcionase que encontré)
    public  void MostrarGanador()
    {
        // Recogemos el valor ganador
        int ganador = GanadorInfo.Ganador;

        // Si el ganador es 1 ,(jugador), mostrará el siguiente mensaje
        if (ganador == 1)
        {
            resultadoFinal.text = "¡Has salvado a la humanidad! \nMuchas gracias";
        }
        // Sie l ganador es 2, significa que el enemigo a ganado    
        else if (ganador == 2)
        {
            resultadoFinal.text = "...La vida humana, \nahora es polvo en el espacio...";
        }
    }
}
