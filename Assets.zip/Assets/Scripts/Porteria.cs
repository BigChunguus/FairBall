using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class Porteria : MonoBehaviour

{
    // Tenemos 2 variables para guardar la puntuacion
    public int puntosJugador1 = 0;
    public int puntosJugador2 = 0;
    // Hhacemos refencia al controlador canvas(puntos actuales) y controlador central (ganador)
    private ControladorCanvas contCan;
    private ControladorCentral contCen;
    void Start()
    {
        // Buscamos y hacemos referenic a a los objetos
        contCan = FindObjectOfType<ControladorCanvas>();
        contCen = FindObjectOfType<ControladorCentral>();
    }

    // Métodos que anotaran los piuntos
    public void AnotarPunto1()
    {
        // Aumentamos 1 punto
        puntosJugador1++;
        // Comprobamos si gana
        contCen.VerificarPuntos(puntosJugador1, puntosJugador2);
        // Actualizamos marcador
        contCan.ActualizarTextoPuntos(puntosJugador1, puntosJugador2);
    }

    public void AnotarPunto2()
    {
       // Aumentamos 1 punto
        puntosJugador2++;
        // Comprobamos si gana
        contCen.VerificarPuntos(puntosJugador1, puntosJugador2);
        // Actualizamos marcador
        contCan.ActualizarTextoPuntos(puntosJugador1, puntosJugador2);
    } 
}