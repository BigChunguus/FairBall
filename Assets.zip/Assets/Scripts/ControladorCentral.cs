using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class ControladorCentral : MonoBehaviour
{
    // Creamos una variable la cual referenciara a la clase "Porteria"
    public Porteria porteria;

    void Start()
    {
        // Buscaremos y asignaremos la instancia de la porteria en la escena
        porteria = FindObjectOfType<Porteria>();
    }

    // Este metodo comprueba el puntaje actual, y si alguno de los 2 a llegado a 7, 
    // llamamos al metodo "MostrarEEscenaFinal", dandole el valor del jugador ganador
    public void VerificarPuntos(int puntosJugador1, int puntosJugador2)
    {
        if (puntosJugador1 >= 7 || puntosJugador2 >= 7)
        {
            
            MostrarEscenaFinal(puntosJugador1 >= 7 ? 1 : 2);
        }
    }

    // Recibe 1 u 2, y lko manda a la escena final, y cargamos la escena final
    void MostrarEscenaFinal(int ganador)
    {
        // Guarda el ganador en una variable estática para que la EscenaFinal pueda acceder a ella
        GanadorInfo.Ganador = ganador;
        SceneManager.LoadScene(2);
    }
}
